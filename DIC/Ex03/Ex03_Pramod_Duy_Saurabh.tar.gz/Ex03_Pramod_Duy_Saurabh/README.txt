Assignment H3.
TEAM:Pramod; Duy; Saurabh

(b) 
> Lambda refers to contrast parameter in the Perona-Malik Diffusivity equation.
> Sigma refers to the width of the gaussian kernel used as a regularisation parameter.

> If the value of lambda is small it means that not only edges of images but also some noise
  structures will be enhanced. Otherwise, if value of lambda is too big, it will lost some 
  information on edges because forward diffusion will be applied on edge whose gradient
  values is smaller than lambda.

> If the sigma is too small, then the noise smoothening effect is reduced which leads to a
  noisy image but if the sigma is too large, then significant amount of image information 
  will be lost due to smoothing by the gaussian kernel, resulting in a blurry image.
  
(c)
> In comparsion with Perona-Malik filtering, Charbonnier method smoothens the edges and 
  has less noise. 
  
(d)
> For a given lambda, Charbonnier filter considers less image structures as edges. In other
  words, it is closer to linear diffusion than Perona-Malik filtering. 

Files  :
├── ch_2_0.2_0.1.pgm - Image denoised with Charbonnier Difussivity
├── diff_ch.pgm - Noise method output with Charbonnier denoisng
├── pm_5_2_0.1.pgm - Image denoised with Perona-Malik Difussivity
├── diff_pm.pgm - Noise method output with Perona-Malik denoisng

Parameters:
> ch_2_0.2_0.1.pgm - Lambda=2; Sigma=0.2; time step=0.1
> pm_5_2_0.1.pgm - Lambda=5; Sigma=2; time step=0.1
