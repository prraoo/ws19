Assignment H4
TEAM:Pramod; Duy; Saurabh

Files:
Ex04_Pramod_Duy_Saurabh
   ├── ced.c
   ├── out_finger.pgm
   ├── out_fire.pgm
   ├── out_ses_100000.pgm
   ├── out_ses_10000.pgm
   ├── out_ses_1000.pgm
   ├── out_ses_100.pgm
   ├── out_ses_200.pgm
   └── README.txt

Parameters:
> out_finger.pgm - CED Enhanced version of finger.pgm.
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=40
	
> out_fire.pgm - CED Enhanced version of fire.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=40
	
> out_ses_100.pgm - CED Enhanced version of seismic.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=100
	
> out_ses_200.pgm - CED Enhanced version of seismic.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=200
	
> out_ses_1000.pgm - CED Enhanced version of seismic.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=1000
	
> out_ses_10000.pgm - CED Enhanced version of seismic.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=10000
	
> out_ses_100000.pgm - CED Enhanced version of seismic.pgm
	C=1, sigma=0.5, rho=4, alpha=0.001, time step=0.2, iterations=100000

